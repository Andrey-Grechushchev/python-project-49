#!/usr/bin/env python3

def main():
    print('Welcome to the Brain Games!__')
    print('!!')

if __name__ == '__main__':
    main()
    print('!')
    welcome_user()
