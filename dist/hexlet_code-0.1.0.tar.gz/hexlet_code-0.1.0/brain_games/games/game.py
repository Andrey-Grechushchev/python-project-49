import prompt


def game(question, correct_answer, i, number_of_questions, name):
    print(f"Question: {question}") # вопрос в каждой игре
    answer = prompt.string("You answer: ") # ждём ответа в каждой игре
    if answer == correct_answer: # проверка в каждой игре во всех играх одинаково
        print("Correct!") # при правильном ответе во всех играх одинаково
        if i == number_of_questions - 1: # проверка о количестве вопросов во всех играх одинаково
            print(f"Congratulations, {name}!") # успешный конец, во всех играх одинаково
    else: # при неправильном ответе
        print(f"""'{answer}' is wrong answer ;(. Correct answer was '{correct_answer}'.
Let's try again, {name}!""") # во всех играх одинаково       
        return False 
