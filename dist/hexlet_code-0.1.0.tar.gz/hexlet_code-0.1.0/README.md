### Hexlet tests and linter status:
[![Actions Status](https://github.com/Andrey-Grechushchev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Andrey-Grechushchev/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/37d5feaf3126df608fe9/maintainability)](https://codeclimate.com/github/Andrey-Grechushchev/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/A9mZTf5Id3d9AC3Qf31DEJZwg.svg)](https://asciinema.org/a/A9mZTf5Id3d9AC3Qf31DEJZwg)

[![asciicast](https://asciinema.org/a/qoQv1Yy2fdte8NOZB22q01bPF.svg)](https://asciinema.org/a/qoQv1Yy2fdte8NOZB22q01bPF)

[![asciicast](https://asciinema.org/a/PeFjl3g6esfX5NdXDDUmBmODk.svg)](https://asciinema.org/a/PeFjl3g6esfX5NdXDDUmBmODk)

[![asciicast](https://asciinema.org/a/VTtWI9N64d0vDUXZh9GlnPeD0.svg)](https://asciinema.org/a/VTtWI9N64d0vDUXZh9GlnPeD0)

[![asciicast](https://asciinema.org/a/MIk93CKGqhhlckvLm1Up7TC8D.svg)](https://asciinema.org/a/MIk93CKGqhhlckvLm1Up7TC8D)
